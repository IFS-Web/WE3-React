import React from 'react';
import { Input } from 'reactstrap';

export function YearDropdown({ value, onChange }) {
  const currentYear = new Date().getFullYear();
  const yearOptions = [currentYear - 2, currentYear - 1, currentYear].map(y => ({
    value: y,
    text: y,
  }));
  return (
    <Input onChange={onChange} type="select">
      <option selected={!value} disabled>
        Nach Jahr Filtern
      </option>
      {Array.from(yearOptions).map((item, index) => (
        <option key={index} value={item.value}>
          {item.text}
        </option>
      ))}
    </Input>
  );
}
