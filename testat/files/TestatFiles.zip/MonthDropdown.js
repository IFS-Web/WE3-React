import React from 'react';
import { Input } from 'reactstrap';

export function MonthDropdown({ value, onChange }) {
  const monthOptions = [
    'Januar',
    'Februar',
    'März',
    'April',
    'Mai',
    'Juni',
    'Juli',
    'August',
    'September',
    'Oktober',
    'November',
    'Dezember',
  ].map((m, i) => ({ value: i + 1, text: m }));
  return (
    <Input onChange={onChange} type="select">
      <option selected={!value} disabled>Nach Monat Filtern</option>
      {Array.from(monthOptions).map((item, index) => (
        <option key={index} value={item.value}>
          {item.text}
        </option>
      ))}
    </Input>
  );
}
