import React from 'react';
import { ButtonGroup, Button } from 'reactstrap';
import TransactionsTable from '../components/TransactionsTable';

export const PaginatedTransactionsTable = ({ user, transactions, skip, total, onBack, onForward }) => {
  return (
    <TransactionsTable user={user} transactions={transactions}>
      <ButtonGroup>
        <Button
          outline={skip === 0}
          disabled={skip === 0}
          style={skip === 0 ? { opacity: '0.4' } : {}}
          onClick={e => {
            e.target.blur();
            onBack();
          }}
        >
          &lt;
        </Button>
        <Button outline disabled style={{ opacity: '0.4' }}>
          Transaktionen {skip + 1} bis {skip + transactions.length} von {total}
        </Button>
        <Button
          disabled={skip + transactions.length >= total}
          onClick={e => {
            e.target.blur();
            onForward();
          }}
        >
          &gt;
        </Button>
      </ButtonGroup>
    </TransactionsTable>
  );
};
